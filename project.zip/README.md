# EasyLearnBot

https://api.telegram.org/bot5405067658:AAGtH8v7gqbGAJ-9qOB3IelU0_66qfOk32c/setwebhook?url=
https://functions.yandexcloud.net/d4ejmm6tevngsmrdhoh5